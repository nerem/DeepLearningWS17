import numpy as np
import tensorflow as tf
import h5py


# Loads one of the subsets (train or test) of the pmjt dataset with labels in the one hot format and inputs normalized such that they have zero mean and standard deviation one.
def load(subset = "train"):
    with  h5py.File("train_test_file_list.h5", "r") as hf:
        x = np.reshape(np.array(hf.get("{}_x".format(subset)), dtype = np.float32), (-1, 28, 28 ,1))
        y = np.array(hf.get("{}_y".format(subset)))
    y = np.eye(10, dtype = np.float32)[np.reshape(y, -1)]
    x = normalize(x).reshape(-1, 28, 28, 1)
    return x, y

# Shifts and scales a batch of images such that they have mean zero and standard deviation one.
def normalize(x):
    x -= np.mean(x, axis = (1, 2)).reshape(-1, 1, 1, 1)
    x /= np.maximum(np.std(x, axis = (1, 2)).reshape(-1, 1, 1, 1), np.sqrt(x.shape[1] * x.shape[2] - 1))
    return x