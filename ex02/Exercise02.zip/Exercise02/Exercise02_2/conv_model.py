import numpy as np
import tensorflow as tf
import math


# Create a model with two convolutional layers and one fully connected layer for the pmjt dataset.
def create_model_two():
    
    # Create tensorflow session.
    sess = tf.Session()
    
    # Placeholders for inputs and labels
    x = tf.placeholder(tf.float32, [None, 28, 28, 1])
    y = tf.placeholder(tf.float32, [None, 10])
    
    # Create two convolutional layers as well as one fully connected layer.
    with tf.variable_scope("layer1"):
        W1 = tf.get_variable("W", [5,5,1,32], initializer = tf.contrib.layers.xavier_initializer())
        b1 = tf.get_variable("b", [32], initializer = tf.initializers.constant(0.1))
        c1 = tf.nn.conv2d(x, W1, strides = [1,1,1,1], padding = "SAME") + b1
        hc1 = tf.nn.relu(c1)

    with tf.variable_scope("layer2"):
        W2 = tf.get_variable("W", [5,5,32,64], initializer = tf.contrib.layers.xavier_initializer())
        b2 = tf.get_variable("b", [64], initializer = tf.initializers.constant(0.1))
        c2 = tf.nn.conv2d(hc1, W2, strides = [1,1,1,1], padding = "SAME") + b2
        hc2 = tf.nn.relu(c2)

    f3 = tf.layers.Flatten()(hc2)
    with tf.variable_scope("layer3"):
        W3 = tf.get_variable("W", [f3.shape[1], 10], initializer = tf.contrib.layers.xavier_initializer())
        b3 = tf.get_variable("b", [10], initializer = tf.initializers.constant(0.1))
        logits = f3 @ W3 + b3
        predictions = tf.nn.softmax(logits)
    
    # Define the cross entropy loss.
    cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels = y, logits = logits))
    
    # Define the optimizer to be used for training.
    global_step = tf.Variable(0, name = "global_step", trainable = False)
    step_size = tf.Variable(0.001, trainable = False)
    train_op = tf.train.AdamOptimizer(step_size).minimize(cross_entropy, global_step = global_step)
    
    # Evaluate model accuracy.
    accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(predictions,1), tf.argmax(y,1)), tf.float32))
    
    # Initialize variables.
    sess.run(tf.global_variables_initializer())
    
    return sess, x, y, logits, predictions, cross_entropy, train_op, accuracy, step_size

# Create a model with one convolutional layer and one fully connected layer for the pmjt dataset.
def create_model_one():
    
    # Create tensorflow session.
    sess = tf.Session()
    
    # Placeholders for inputs and labels
    x = tf.placeholder(tf.float32, [None, 28, 28, 1])
    y = tf.placeholder(tf.float32, [None, 10])
    
    # Create two convolutional layers as well as one fully connected layer.
    with tf.variable_scope("layer1"):
        W1 = tf.get_variable("W", [5,5,1,32], initializer = tf.contrib.layers.xavier_initializer())
        b1 = tf.get_variable("b", [32], initializer = tf.initializers.constant(0.1))
        c1 = tf.nn.conv2d(x, W1, strides = [1,1,1,1], padding = "SAME") + b1
        hc1 = tf.nn.relu(c1)

    f2 = tf.layers.Flatten()(hc1)
    with tf.variable_scope("layer2"):
        W2 = tf.get_variable("W", [f2.shape[1], 10], initializer = tf.contrib.layers.xavier_initializer())
        b2 = tf.get_variable("b", [10], initializer = tf.initializers.constant(0.1))
        logits = f2 @ W2 + b2
        predictions = tf.nn.softmax(logits)
    
    # Define the cross entropy loss.
    cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels = y, logits = logits))
    
    # Define the optimizer to be used for training.
    global_step = tf.Variable(0, name = "global_step", trainable = False)
    step_size = tf.Variable(0.001, trainable = False)
    train_op = tf.train.AdamOptimizer(step_size).minimize(cross_entropy, global_step = global_step)
    
    # Evaluate model accuracy.
    accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(predictions,1), tf.argmax(y,1)), tf.float32))
    
    # Initialize variables.
    sess.run(tf.global_variables_initializer())
    
    return sess, x, y, logits, predictions, cross_entropy, train_op, accuracy, step_size

# Create minibatches and train for one epoch. If shuffle is true, then the data is shuffled, before the minibatches are generated.
def train_epoch(inputs, labels, batch_size, sess, x, y, train_op, loss, accuracy, shuffle = True):
    
    # Create an index array, which is randomly shuffled, if shuffle is true.
    s = inputs.shape[0]
    index = np.random.permutation(s) if shuffle else np.arange(s)
    
    # Iterate through the batches and record loss as well as accuracy.
    losses = []
    accuracies = []
    for i in range(math.ceil(inputs.shape[0] / batch_size)):
        batch_index = index[i * batch_size : min((i + 1) * batch_size, s)]
        l, a = train(inputs[batch_index], labels[batch_index], sess, x, y, train_op, loss, accuracy)
        losses.append(l)
        accuracies.append(a)
    
    return losses, accuracies

# Run one training step.
def train(inputs, labels, sess, x, y, train_op, loss, accuracy):
    
    feed_dict = {x: inputs, y: labels}
    _, l, a = sess.run([train_op, loss, accuracy], feed_dict)
    
    return l, a

# Evaluate performance on a given dataset.
def evaluate(inputs, labels, sess, x, y, loss, accuracy):    
    return sess.run([loss, accuracy], {x: inputs, y: labels})


































