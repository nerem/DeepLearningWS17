import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

import pmjt_data
from conv_model import create_model_two, train_epoch, evaluate

# Experimenting with training and different step sizes shows that the process diverges with a step size too large
# and converges very slowly with a step size too small.


# Load the data.
x_train, y_train = pmjt_data.load("train")
x_test, y_test = pmjt_data.load("test")

# Create the model with two layers of convolutions.
sess, x, y, logits, predictions, cross_entropy, train_op, accuracy, step_size = create_model_two()

# Function for training and result visualization. Trains for ten epochs with given step size.
def train_model(s):

    # Initialize variables.
    sess.run(tf.global_variables_initializer())
    sess.run(step_size.assign(s))

    # Train the model.
    train_loss = []
    train_acc = []
    eval_loss = []
    eval_acc = []
    for _ in range(10):
        l, a = train_epoch(x_train, y_train, 463, sess, x, y, train_op, cross_entropy, accuracy, shuffle=True)
        train_loss = np.concatenate((train_loss, l))
        train_acc = np.concatenate((train_acc, a))
        l, a = evaluate(x_test, y_test, sess, x, y, cross_entropy, accuracy)
        eval_loss = np.concatenate((eval_loss, [l]))
        eval_acc = np.concatenate((eval_acc, [a]))

    # Plot loss and accuracy over training steps. (43 steps is one epoch)
    plt.figure("Loss (step size: {})".format(s))
    plt.plot(np.arange(train_loss.shape[0]), train_loss)
    plt.plot(43 * (np.arange(eval_loss.shape[0]) + 1), eval_loss)
    plt.figure("Accuracy (step size: {})".format(s))
    plt.plot(np.arange(train_acc.shape[0]), train_acc)
    plt.plot(43 * (np.arange(eval_acc.shape[0]) + 1), eval_acc)
    return

# Step size 0.001
train_model(0.001)

# Step size 0.01
train_model(0.01)

# Step size 0.0001
train_model(0.0001)

# Step size 0.00001
train_model(0.00001)

plt.show()