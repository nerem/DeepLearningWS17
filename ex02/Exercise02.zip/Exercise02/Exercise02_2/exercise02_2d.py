import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

import pmjt_data
from conv_model import create_model_one, train_epoch, evaluate


# Load the data.
x_train, y_train = pmjt_data.load("train")
x_test, y_test = pmjt_data.load("test")

# Create the model with one layer of convolutions.
sess, x, y, logits, predictions, cross_entropy, train_op, accuracy, step_size = create_model_one()

# Train the model.
train_loss = []
train_acc = []
eval_loss = []
eval_acc = []
for _ in range(20):
    l, a = train_epoch(x_train, y_train, 463, sess, x, y, train_op, cross_entropy, accuracy, shuffle = True)
    train_loss = np.concatenate((train_loss, l))
    train_acc = np.concatenate((train_acc, a))
    l, a = evaluate(x_test, y_test, sess, x, y, cross_entropy, accuracy)
    eval_loss = np.concatenate((eval_loss, [l]))
    eval_acc = np.concatenate((eval_acc, [a]))

# Plot loss and accuracy over training steps. (43 steps is one epoch)
plt.figure("Loss")
plt.plot(np.arange(train_loss.shape[0]), train_loss)
plt.plot(43 * (np.arange(eval_loss.shape[0]) + 1), eval_loss)
plt.figure("Accuracy")
plt.plot(np.arange(train_acc.shape[0]), train_acc)
plt.plot(43 * (np.arange(eval_acc.shape[0]) + 1), eval_acc)
plt.show()
