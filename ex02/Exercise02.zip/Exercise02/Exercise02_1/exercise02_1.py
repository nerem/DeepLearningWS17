import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf

import pmjt_data
from logreg_model import create_model, train_epoch

# Load the data.
x_train, y_train = pmjt_data.load("train")
x_test, y_test = pmjt_data.load("test")

# Create the model.
sess, x, y, W, b, logits, predictions, cross_entropy, train_op, accuracy = create_model(step_size = 0.1)

# Train the model.
for _ in range(20):
    train_epoch(x_train, y_train, 463, sess, x, y, train_op, cross_entropy, accuracy, shuffle = True)

# Visualize the weights and some example images.
plt.figure("Weights")
show_weights(sess.run(W))
plt.figure("Examples")
show_examples(x_train, y_train)

def show_weights(weights):
    for i in range(10):
        plt.subplot(3, 4, i + 1)
        plt.imshow(weights[:,i].reshape(28, 28))
    plt.show()
    return

def show_examples(images, labels):
    for i in range(10):
        plt.subplot(3, 4, i + 1)
        index = np.random.permutation(np.where(labels[:, i] == 1)[0])[0]
        plt.imshow(images[index].reshape(28, 28))
    plt.show()
    return
