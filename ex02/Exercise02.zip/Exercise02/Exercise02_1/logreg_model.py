import numpy as np
import tensorflow as tf
import math


# Create a linear regression model for the pmjt dataset.
def create_model(step_size = 0.001):
    
    # Create tensorflow session.
    sess = tf.Session()
    
    # Placeholders for inputs and labels
    x = tf.placeholder(tf.float32, [None, 784])
    y = tf.placeholder(tf.float32, [None, 10])
    
    # Trainable variables for the logistic regression
    W = tf.get_variable("W", [784, 10])
    b = tf.get_variable("b", [10])
    
    # Calculate the logits and the softmax predictions.
    logits = x @ W + b
    predictions = tf.nn.softmax(logits)
    
    # Define the cross entropy loss.
    cross_entropy = tf.reduce_mean(tf.nn.softmax_cross_entropy_with_logits(labels = y, logits = logits))
    
    # Define the optimizer to be used for training.
    global_step = tf.Variable(0, name = "global_step", trainable = False)
    train_op = tf.train.GradientDescentOptimizer(step_size).minimize(cross_entropy, global_step = global_step)
    
    # Evaluate model accuracy.
    accuracy = tf.reduce_mean(tf.cast(tf.equal(tf.argmax(predictions,1), tf.argmax(y,1)), tf.float32))
    
    # Initialize variables.
    sess.run(tf.global_variables_initializer())
    
    return sess, x, y, W, b, logits, predictions, cross_entropy, train_op, accuracy

# Create minibatches and train for one epoch. If shuffle is true, then the data is shuffled, before the minibatches are generated.
def train_epoch(inputs, labels, batch_size, sess, x, y, train_op, loss, accuracy, shuffle = True):
    
    # Create an index array, which is randomly shuffled, if shuffle is true.
    s = inputs.shape[0]
    index = np.random.permutation(s) if shuffle else np.arange(s)
    
    # Iterate through the batches and record loss as well as accuracy.
    losses = []
    accuracies = []
    for i in range(math.ceil(inputs.shape[0] / batch_size)):
        batch_index = index[i * batch_size : min((i + 1) * batch_size, s)]
        l, a = train(inputs[batch_index], labels[batch_index], sess, x, y, train_op, loss, accuracy)
        losses.append(l)
        accuracies.append(a)
    
    return losses, accuracies

# Run one training step.
def train(inputs, labels, sess, x, y, train_op, loss, accuracy):
    
    feed_dict = {x: inputs, y: labels}
    _, l, a = sess.run([train_op, loss, accuracy], feed_dict)
    
    return l, a




































